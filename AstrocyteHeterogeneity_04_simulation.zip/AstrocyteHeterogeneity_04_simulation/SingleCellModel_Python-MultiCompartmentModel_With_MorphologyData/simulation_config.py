"""
Need a better name... temperature, simulation time, etc.

"""
TEMPERATURE = 311  # [K]
